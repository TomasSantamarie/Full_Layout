package com.example.full_layout

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Navigate : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_navigate)
    }
}